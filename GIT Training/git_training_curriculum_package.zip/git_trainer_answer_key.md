
# 📘 Trainer Answer Key: Git + Bitbucket Curriculum Assessments

---

## ✅ Module 1: Git Fundamentals – Answers

**Q1:** C – Initializes a new Git repository in the current directory  
**Q2:** B – `git add .`  
**Q3:** C – `git log`  
**Q4:** D – To queue up selected changes before a commit  
**Q5:** C – Git asks for remote branch tracking setup

**Q6 (Open):** Undo with `git reset HEAD~1` or `git rm --cached .env` and use `.gitignore`  
**Q7 (Open):** Someone pushed to main before you; run `git pull --rebase` or re-merge latest main

---

## ✅ Module 2: Branching Strategies – Answers

**Q1:** B – Allows parallel development without impacting `main`  
**Q2:** C – Integrates features before a release  
**Q3:** B – Commits made directly to `main`, with fast integration  
**Q4:** D – `git checkout -b`  
**Q5:** D – Delete it to keep the repo clean

**Q6 (Open):** Feature → develop → release/1.0 → main → tag v1.0 → merge release back to develop  
**Q7 (Open):** Use feature flags, testing, and quick PR review to safely merge frequently

---

## ✅ Module 3: Conflict Resolution – Answers

**Q1:** C – Editing the same lines in the same file on two branches  
**Q2:** C – Conflict markers (`<<<<<<<`, etc.)  
**Q3:** D – `git merge --abort`  
**Q4:** C – `gitk`  
**Q5:** C – Commit the resolved file

**Q6 (Open):** Simulate by editing same line; resolve manually using editor or `git mergetool`  
**Q7 (Open):** Rebase rewrote history; pull with `--rebase`, or reset and reapply changes

---

## ✅ Module 4: Bitbucket Collaboration – Answers

**Q1:** C – Facilitate collaborative code review  
**Q2:** C – All builds and approvals are complete  
**Q3:** D – Delete the feature branch to keep history clean  
**Q4:** C – Anyone with write or reviewer access  
**Q5:** D – All of the above

**Q6 (Open):** Fix test or pipeline error, re-push; Bitbucket requires passing build, 1+ approvals  
**Q7 (Open):** Issue key missing from commit/PR/branch, or Jira integration misconfigured

---

## ✅ Module 5: CI/CD & Pipelines – Answers

**Q1:** C – The CI/CD pipeline logic  
**Q2:** C – A single action or phase within the pipeline  
**Q3:** B – Pipeline automatically executes defined steps  
**Q4:** C – Using repository secrets (environment variables)  
**Q5:** B – `tags:`

**Q6 (Open):** YAML with `branches:`, `tags:`, caches for pip, secrets for deploy  
**Q7 (Open):** Use fixed versions in `requirements.txt`, add caching, review logs in failed step

---

Each open-ended question should be discussed interactively with learners, encouraging:
- Step-by-step reasoning
- Diagramming where applicable (especially in merge or PR issues)
- Usage of real repositories to simulate scenarios

